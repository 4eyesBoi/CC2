package com.ud.ciencias.computacion.talleres;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TalleresApplicationTests {

	@Test
	void contextLoads() {
	}

}
