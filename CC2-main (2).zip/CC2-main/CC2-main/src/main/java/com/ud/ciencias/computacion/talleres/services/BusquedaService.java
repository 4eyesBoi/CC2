
package com.ud.ciencias.computacion.talleres.services;

import org.springframework.stereotype.Service;

@Service
public class BusquedaService {

    public void buscarServicioActivo() {
        
        System.out.println("buscando servicio activo...");
        // Lógica para buscar servicios activos
        
    }

}

