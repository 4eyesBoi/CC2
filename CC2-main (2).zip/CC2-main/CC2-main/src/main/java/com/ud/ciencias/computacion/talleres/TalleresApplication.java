package com.ud.ciencias.computacion.talleres;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TalleresApplication {

	public static void main(String[] args) {
		SpringApplication.run(TalleresApplication.class, args);
	}
}
